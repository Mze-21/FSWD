/**
 * Lab 01 - Full Stack Web Development
 * Simple Express server that serves the static Bootstrap portfolio
 * from the /public folder.
 *
 * Run with:  npm install   then   npm start
 * Visit:     http://localhost:3000
 */

const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Serve everything inside /public as static files (index.html, css, images, etc.)
app.use(express.static(path.join(__dirname, "public")));

// A tiny API route to show a working back-end endpoint,
// e.g. for a future "Contact" form or dynamic content.
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    message: "Server is up and running.",
    timestamp: new Date().toISOString(),
  });
});

// Fallback: send index.html for any other route (simple single-page setup)
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Portfolio server running at http://localhost:${PORT}`);
});
