# Lab 01 - Full Stack Web Development

Personal portfolio built for the Full-Stack Web Development lab. The
front-end is a single Bootstrap 5 page; a small Express back-end serves it
and exposes one sample API route.

## Project structure

```
lab01-fullstack/
├── public/
│   └── index.html      # Front-end: navbar, About Me (grid), Skills (cards), Contact
├── server.js           # Back-end: Express static file server + /api/health route
├── package.json         # Node dependencies and start script
├── .gitignore
└── README.md
```

## Front-end

`public/index.html` contains:
- A responsive Bootstrap navbar
- An **About Me** section built with the Bootstrap grid system
- A **Skills** section using Bootstrap cards
- A **Contact** section with a styled button linking to an email address

All styling uses Bootstrap 5 (via CDN) plus a small custom `<style>` block
for the color palette, typography, and photo framing.

## Back-end

`server.js` is a minimal Express server:
- Serves the `public/` folder as static files, so opening
  `http://localhost:3000` loads `index.html`
- Exposes `GET /api/health` which returns a small JSON status payload —
  a starting point for adding real dynamic features later (e.g. a working
  contact form endpoint)

## Running locally

```bash
npm install
npm start
```

Then open http://localhost:3000 in your browser.

## Submitting / pushing to GitHub

```bash
# from inside this folder (or after copying its contents into your existing repo)
git init                     # only if the repo isn't already initialized
git add .
git commit -m "Add Express back-end serving the Bootstrap portfolio front-end"
git remote add origin <your-lab01-fullstack-repo-url>   # only if not already set
git push origin main
```

If you already have earlier commits in `lab01-fullstack` (navbar/About Me,
then Skills/Contact), this becomes your third commit, adding the back-end
layer on top of the front-end work.
